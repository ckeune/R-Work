
install.packages('devtools')


devtools::install_github('rstudio/shinyapps')
devtools::install_github("Tatvic/RGoogleAnalytics")

required_libraries <- c('ggplot2',
                        'reshape2',
                        'stringr',
                        'lubridate',
                        'dplyr',
                        'scales',
                        'googleVis',
                        'shiny',
                        'magrittr', 
                        'lattice',
                       # 'shinyGoogleCharts',
                        'RGoogleAnalytics',
                        'dplyr',
                        'plyr',
                        'httr',
                        'lubridate')
)

#Install/load required libraries
for (lib_name in required_libraries){
  if (!require(lib_name, character.only = T)) 
    install.packages(lib_name)
  library(lib_name, character.only = T)
}

require(RGoogleAnalytics)

token <- Auth(client.id,client.secret)
# Save the token object for future sessions
save(token,file="./token_file")
# In future sessions it can be loaded by running load("./token_file")
ValidateToken(token)
# Build a list of all the Query Parameters
query.list <- Init(start.date = "2013-11-28",
                   end.date = "2013-12-04",
                   dimensions = "ga:date,ga:pagePath,ga:hour,ga:medium",
                   metrics = "ga:sessions,ga:pageviews",
                   max.results = 10000,
                   sort = "-ga:date",
                   table.id = "ga:33093633")
# Create the Query Builder object so that the query parameters are validated
ga.query <- QueryBuilder(query.list)
# Extract the data and store it in a data-frame
ga.data <- GetReportData(ga.query, token, split_daywise = T, delay = 5)



